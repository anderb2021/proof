"""
Finance AI Marketplace — Replit-ready MVP
- FastAPI app with unified /orchestrate
- Multi-tenant API keys (SQLite)
- Model catalog (YAML -> DB)
- Compare page & dashboard
- Basic billing export
- BYO provider keys via headers
"""
import os, time, json, re, sqlite3, yaml
from typing import Optional, Literal, Dict, Any
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
import httpx

DB_PATH = "./orchestrator.db"
CATALOG_PATH = "./config/models.yaml"

# ---------------- DB ----------------
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db(); cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS usage_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER,
        tenant TEXT,
        task TEXT,
        chosen_provider TEXT,
        latency_ms INTEGER,
        input_tokens INTEGER,
        output_tokens INTEGER,
        est_cost_usd REAL,
        status TEXT,
        error TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS tenants (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        contact_email TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS api_keys (
        key TEXT PRIMARY KEY,
        tenant_id TEXT NOT NULL,
        created_ts INTEGER,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id)
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS providers (
        key TEXT PRIMARY KEY,
        display_name TEXT NOT NULL
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS models_catalog (
        id TEXT PRIMARY KEY,
        provider_key TEXT NOT NULL,
        family TEXT,
        context_window INT,
        notes TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS model_prices (
        model_id TEXT PRIMARY KEY,
        input_per_1k REAL NOT NULL,
        output_per_1k REAL NOT NULL,
        currency TEXT DEFAULT 'USD'
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS benchmarks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts INTEGER,
        task TEXT,
        model_id TEXT,
        latency_ms INTEGER,
        quality_score REAL,
        cost_usd REAL
    )""")
    con.commit()
    # seed demo
    cur.execute("SELECT COUNT(*) AS c FROM tenants")
    if cur.fetchone()["c"] == 0:
        cur.execute("INSERT INTO tenants (id,name,contact_email) VALUES (?,?,?)",
                    ("demo-tenant","Demo Tenant","demo@example.com"))
        cur.execute("INSERT INTO api_keys (key,tenant_id,created_ts) VALUES (?,?,?)",
                    ("dev-key","demo-tenant",int(time.time())))
        con.commit()
    con.close()

def upsert_catalog():
    if not os.path.exists(CATALOG_PATH): return
    with open(CATALOG_PATH,"r") as f:
        cat = yaml.safe_load(f) or {}
    con = db(); cur = con.cursor()
    for p in cat.get("providers", []):
        cur.execute("INSERT OR REPLACE INTO providers (key,display_name) VALUES (?,?)",
                    (p["key"], p["display_name"]))
    for m in cat.get("models", []):
        cur.execute("INSERT OR REPLACE INTO models_catalog (id,provider_key,family,context_window,notes) VALUES (?,?,?,?,?)",
                    (m["id"], m["provider_key"], m.get("family"), m.get("context_window"), m.get("notes")))
        price = m.get("price", {})
        if price:
            cur.execute("INSERT OR REPLACE INTO model_prices (model_id,input_per_1k,output_per_1k,currency) VALUES (?,?,?,?)",
                        (m["id"], float(price["input_per_1k"]), float(price["output_per_1k"]), "USD"))
    con.commit(); con.close()

init_db()
upsert_catalog()

# ---------------- App ----------------
app = FastAPI(title="Finance AI Marketplace — MVP")
templates = Jinja2Templates(directory="./templates")

# ------------- utils -------------
def get_tenant_id(x_api_key: Optional[str]) -> str:
    if not x_api_key: raise HTTPException(401,"Missing API key")
    con = db(); cur = con.cursor()
    cur.execute("SELECT tenant_id FROM api_keys WHERE key = ?", (x_api_key,))
    row = cur.fetchone(); con.close()
    if not row: raise HTTPException(401,"Invalid API key")
    return row["tenant_id"]

def estimate_tokens(text: str) -> int:
    return max(1, len(text)//4)

def catalog():
    con = db(); cur = con.cursor()
    cur.execute("""SELECT mc.id, mc.provider_key, mc.family, mc.context_window,
                          mp.input_per_1k, mp.output_per_1k
                   FROM models_catalog mc LEFT JOIN model_prices mp ON mp.model_id = mc.id""")
    models = []
    for r in cur.fetchall():
        models.append({"id": r[0], "provider_key": r[1], "family": r[2],
                       "context_window": r[3],
                       "price": {"input_per_1k": r[4], "output_per_1k": r[5]}})
    cur.execute("SELECT key, display_name FROM providers")
    providers = [{"key": r[0], "display_name": r[1]} for r in cur.fetchall()]
    con.close()
    return {"providers": providers, "models": models}

def estimate_cost(model_id: str, in_toks: int, out_toks: int) -> float:
    con = db(); cur = con.cursor()
    cur.execute("SELECT input_per_1k,output_per_1k FROM model_prices WHERE model_id=?", (model_id,))
    r = cur.fetchone(); con.close()
    if not r: return 0.0
    return (in_toks/1000.0)*float(r[0]) + (out_toks/1000.0)*float(r[1])

def choose_by_preset(preset: Optional[str], text: str) -> str:
    # very simple: cheapest or default to gpt-4o-mini
    cat = catalog()["models"]
    if preset == "cheapest":
        # sum input+output per 1k
        ranked = sorted(cat, key=lambda m: (m["price"]["input_per_1k"] or 0)+(m["price"]["output_per_1k"] or 0))
        return ranked[0]["id"] if ranked else "openai:gpt-4o-mini"
    return "openai:gpt-4o-mini"

# -------- providers --------
async def call_openai(prompt: str, model: str, x_openai_key: Optional[str]) -> str:
    key = x_openai_key or os.getenv("OPENAI_API_KEY","")
    if not key:
        return "[OPENAI_API_KEY not set — mock response] " + prompt[:200]
    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    payload = {"model": model, "messages":[{"role":"user","content":prompt}], "temperature":0.2}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()
        return data["choices"][0]["message"]["content"].strip()

async def call_anthropic(prompt: str, model: str, x_anthropic_key: Optional[str]) -> str:
    key = x_anthropic_key or os.getenv("ANTHROPIC_API_KEY","")
    if not key:
        return "[ANTHROPIC_API_KEY not set — mock response] " + prompt[:200]
    url = "https://api.anthropic.com/v1/messages"
    headers = {"x-api-key": key, "anthropic-version":"2023-06-01", "content-type":"application/json"}
    payload = {"model": model, "max_tokens": 512, "messages":[{"role":"user","content":prompt}], "temperature":0.2}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()
        # get text content
        blocks = data.get("content", [])
        texts = [b.get("text","") for b in blocks if isinstance(b, dict) and b.get("type")=="text"]
        return "".join(texts).strip() or json.dumps(data)[:500]

async def dispatch(model_id: str, prompt: str, x_openai_key: Optional[str], x_anthropic_key: Optional[str]) -> str:
    if model_id.startswith("openai:"):
        return await call_openai(prompt, model=model_id.split(":",1)[1], x_openai_key=x_openai_key)
    if model_id.startswith("anthropic:"):
        # map short names to full ids
        mm = {"claude-3-haiku":"claude-3-haiku-20240307","claude-3-opus":"claude-3-opus-20240229"}
        short = model_id.split(":",1)[1]
        return await call_anthropic(prompt, model=mm.get(short, short), x_anthropic_key=x_anthropic_key)
    return f"[Unknown provider/model {model_id}]"

# -------- Schemas --------
class Policies(BaseModel):
    latency: Literal["low","medium","high"] = "medium"
    cost: Literal["low","medium","high"] = "medium"
    compliance: Literal["pii-safe","strict","none"] = "pii-safe"
    preset: Optional[Literal["cheapest","fastest","best_on_finance"]] = None

class OrchestrateRequest(BaseModel):
    task: Literal["general","summarize","classify","qa","chat"] = "general"
    input: str
    policies: Policies = Policies()
    tenant: Optional[str] = "default"
    hint: Optional[str] = None  # explicit model override

class OrchestrateResponse(BaseModel):
    output: str
    chosen_provider: str
    latency_ms: int
    input_tokens: int
    output_tokens: int
    est_cost_usd: float

# -------- Routes --------
@app.get("/health")
def health(): return {"status":"ok"}

@app.get("/providers")
def providers():
    con = db(); cur = con.cursor()
    cur.execute("SELECT key, display_name FROM providers")
    provs = [{"key": r[0], "display_name": r[1]} for r in cur.fetchall()]
    con.close()
    return {"providers": provs, "env":{"openai": bool(os.getenv("OPENAI_API_KEY")), "anthropic": bool(os.getenv("ANTHROPIC_API_KEY"))}}

@app.get("/models")
def models():
    return catalog()

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    con = db(); cur = con.cursor()
    cur.execute("""SELECT ts, tenant, task, chosen_provider, latency_ms, input_tokens, output_tokens, est_cost_usd, status, error
                   FROM usage_logs ORDER BY id DESC LIMIT 200""")
    rows_raw = cur.fetchall(); con.close()
    rows = [{
        "ts": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(r[0])),
        "tenant": r[1], "task": r[2], "provider": r[3], "latency_ms": r[4],
        "input_tokens": r[5], "output_tokens": r[6], "est_cost_usd": r[7],
        "status": r[8], "error": r[9]
    } for r in rows_raw]
    total_cost = sum(r[7] for r in rows_raw) if rows_raw else 0.0
    avg_latency = int(sum(r[4] for r in rows_raw)/len(rows_raw)) if rows_raw else 0
    return templates.TemplateResponse("dashboard.html", {"request": request, "rows": rows, "stats": {"total_requests": len(rows), "total_cost": total_cost, "avg_latency_ms": avg_latency}})

@app.get("/compare", response_class=HTMLResponse)
def compare(request: Request, task: str="summarize_10k"):
    # MVP: show latest usage averages per model (since we don't persist benchmarks yet)
    con = db(); cur = con.cursor()
    cur.execute("""SELECT chosen_provider, AVG(latency_ms), AVG(est_cost_usd), AVG(output_tokens)
                   FROM usage_logs GROUP BY chosen_provider""")
    avg = {r[0]: {"avg_latency": int(r[1] or 0), "avg_cost": float(r[2] or 0.0)} for r in cur.fetchall()}
    cat = catalog()
    rows = []
    for m in cat["models"]:
        a = avg.get(m["id"], {"avg_latency": 0, "avg_cost": 0.0})
        rows.append({
            "model_id": m["id"],
            "provider_key": m["provider_key"],
            "context_window": m["context_window"],
            "avg_latency": a["avg_latency"],
            "avg_cost": a["avg_cost"],
            "avg_quality": 0.0  # placeholder in MVP
        })
    return templates.TemplateResponse("compare.html", {"request": request, "task": task, "rows": rows})

@app.get("/billing/usage")
def billing_usage(tenant_id: Optional[str]=None):
    con = db(); cur = con.cursor()
    if tenant_id:
        cur.execute("SELECT COUNT(*), SUM(input_tokens), SUM(output_tokens), SUM(est_cost_usd) FROM usage_logs WHERE tenant = ?", (tenant_id,))
    else:
        cur.execute("SELECT COUNT(*), SUM(input_tokens), SUM(output_tokens), SUM(est_cost_usd) FROM usage_logs")
    c, it, ot, cost = cur.fetchone()
    con.close()
    return {"requests": c or 0, "input_tokens": it or 0, "output_tokens": ot or 0, "est_cost_usd": float(cost or 0.0)}

@app.get("/billing/usage.csv", response_class=PlainTextResponse)
def billing_usage_csv(tenant_id: Optional[str]=None):
    d = billing_usage(tenant_id)
    return "requests,input_tokens,output_tokens,est_cost_usd\n{},{},{},{}".format(d["requests"], d["input_tokens"], d["output_tokens"], d["est_cost_usd"])

# -------- Orchestrate --------
class Headers:
    def __init__(self, x_openai_key: Optional[str], x_anthropic_key: Optional[str]):
        self.x_openai_key = x_openai_key
        self.x_anthropic_key = x_anthropic_key

@app.post("/orchestrate", response_model=OrchestrateResponse)
async def orchestrate(req: OrchestrateRequest, x_api_key: Optional[str] = Header(default=None),
                      x_openai_key: Optional[str] = Header(default=None),
                      x_anthropic_key: Optional[str] = Header(default=None)):
    tenant_id = get_tenant_id(x_api_key)
    start = time.time()
    model_id = req.hint or choose_by_preset(req.policies.preset, req.input)
    in_tokens = estimate_tokens(req.input)
    out_tokens_guess = 400

    status, err, output = "ok", None, ""
    try:
        output = await dispatch(model_id, req.input, x_openai_key, x_anthropic_key)
    except httpx.HTTPStatusError as e:
        status, err = "http_error", f"{e.response.status_code}: {e.response.text[:200]}"
        output = f"Provider error: {err}"
    except Exception as e:
        status, err = "error", str(e)[:300]
        output = f"Error: {err}"

    latency_ms = int((time.time()-start)*1000)
    out_tokens = max(out_tokens_guess, estimate_tokens(output))
    est_cost = estimate_cost(model_id, in_tokens, out_tokens)

    con = db(); cur = con.cursor()
    cur.execute("""INSERT INTO usage_logs (ts, tenant, task, chosen_provider, latency_ms, input_tokens, output_tokens, est_cost_usd, status, error)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (int(time.time()), tenant_id, req.task, model_id, latency_ms, in_tokens, out_tokens, est_cost, status, err))
    con.commit(); con.close()

    return OrchestrateResponse(output=output, chosen_provider=model_id, latency_ms=latency_ms,
                               input_tokens=in_tokens, output_tokens=out_tokens, est_cost_usd=est_cost)
