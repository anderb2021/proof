#!/usr/bin/env python3
import os, json, time, httpx

BASE = os.environ.get("MARKETPLACE_BASE_URL", "http://localhost:8080")
API_KEY = os.environ.get("MARKETPLACE_API_KEY", "dev-key")

def run():
    models = httpx.get(f"{BASE}/models").json()
    model_ids = [m["id"] for m in models["models"]]
    tasks = []
    with open("bench/finance_prompts.jsonl","r") as f:
        for line in f:
            tasks.append(json.loads(line))

    for t in tasks:
        for mid in model_ids:
            payload = {
                "task": "general",
                "input": t["input"],
                "policies": {"latency":"medium","cost":"medium","compliance":"pii-safe"},
                "tenant": "bench",
                "hint": mid
            }
            start = time.time()
            r = httpx.post(f"{BASE}/orchestrate", headers={"X-API-Key": API_KEY, "Content-Type": "application/json"}, json=payload, timeout=120)
            elapsed = int((time.time()-start)*1000)
            try:
                data = r.json()
                output = data.get("output","")
            except Exception:
                output = r.text

            # naive keyword score
            kws = t.get("expected_keywords", [])
            q = (sum(1 for k in kws if k.lower() in output.lower())/len(kws)) if kws else 0.0
            print(json.dumps({"task": t["task"], "model": mid, "latency_ms": elapsed, "quality_score": q, "snippet": output[:160].replace("\n"," ")}))

if __name__ == "__main__":
    run()
